@echo off
setlocal
cd /d "%~dp0"
title Gogo - instalar o ajudante
call "%~dp0suporte\node.cmd" baixar
if errorlevel 1 goto :fim
"%NODE_EXE%" helper\install.ts %*
:fim
echo.
pause
