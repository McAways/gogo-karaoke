#!/bin/sh
# Dois cliques no Finder abrem este arquivo no Terminal. Deixe a janela aberta enquanto usa o app.
cd "$(dirname "$0")" || exit 1
if ! . ./suporte/node.sh; then
  printf 'Aperte Enter para fechar. '; read -r _
  exit 1
fi
if [ ! -d node_modules/ws ]; then
  echo 'Falta instalar. Abra o arquivo "instalar" primeiro.'
  printf 'Aperte Enter para fechar. '; read -r _
  exit 1
fi
"$NODE_EXE" helper/server.ts
status=$?
if [ "$status" -ne 0 ]; then
  printf 'Aperte Enter para fechar. '; read -r _
fi
exit "$status"
