#!/bin/sh
cd "$(dirname "$0")" || exit 1
if . ./suporte/node.sh; then
  SITE="$1"
  if [ -z "$SITE" ]; then
    printf 'Endereço do app publicado (ex.: https://meu-gogo.vercel.app): '
    read -r SITE
  fi
  "$NODE_EXE" helper/server.ts permitir "$SITE"
fi
echo
printf 'Aperte Enter para fechar. '; read -r _
