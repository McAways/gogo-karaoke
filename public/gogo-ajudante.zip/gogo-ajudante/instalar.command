#!/bin/sh
# Dois cliques no Finder abrem este arquivo no Terminal.
cd "$(dirname "$0")" || exit 1
if . ./suporte/node.sh baixar; then
  "$NODE_EXE" helper/install.ts "$@"
fi
echo
printf 'Aperte Enter para fechar. '; read -r _
