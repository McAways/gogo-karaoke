# Acha um Node que sirva (22.18 ou mais novo). Se a máquina não tiver, baixa um só para esta pasta.
# Deixa NODE_EXE apontando para ele e põe a pasta dele na frente do PATH (o npm fica ao lado).
# Uso, de dentro da pasta do ajudante:  . ./suporte/node.sh [baixar]

GOGO_RUNTIME="$(pwd)/runtime"
GOGO_NODE_VERSION="v22.23.2"

gogo_node_ok() {
  "$1" -e 'const [a,b]=process.versions.node.split(".").map(Number);process.exit(a>22||(a===22&&b>=18)?0:1)' >/dev/null 2>&1
}

NODE_EXE=""
if [ -x "$GOGO_RUNTIME/bin/node" ] && gogo_node_ok "$GOGO_RUNTIME/bin/node"; then
  NODE_EXE="$GOGO_RUNTIME/bin/node"
elif command -v node >/dev/null 2>&1 && gogo_node_ok "$(command -v node)"; then
  NODE_EXE="$(command -v node)"
fi

if [ -z "$NODE_EXE" ]; then
  if [ "$1" != "baixar" ]; then
    echo 'Falta instalar. Abra o arquivo "instalar" primeiro.'
    return 1
  fi
  case "$(uname -s)-$(uname -m)" in
    Darwin-arm64) GOGO_NODE_ARCH="darwin-arm64"; GOGO_NODE_SUM="61130f394c1630d211dd50aecc4353d379480f36d3ac913cd85dbba1aed585c6" ;;
    Darwin-x86_64) GOGO_NODE_ARCH="darwin-x64"; GOGO_NODE_SUM="58e99022c2ff89395576cc7fd4d98cea24bb68081475d5f88b801ee8729fb026" ;;
    Linux-x86_64) GOGO_NODE_ARCH="linux-x64"; GOGO_NODE_SUM="b294a556e639d64338823920e5866c21c02741742d2e1529ee1a225c1ec9252a" ;;
    Linux-aarch64 | Linux-arm64) GOGO_NODE_ARCH="linux-arm64"; GOGO_NODE_SUM="013b59cfd2819703a6f4a14ab891fc46fc2a4e3f5bcd92de3fb4929b43e35b30" ;;
    *)
      echo "Não há um Node pronto para este sistema ($(uname -s) $(uname -m)). Instale o Node 22.18 ou mais novo e abra o instalador de novo."
      return 1
      ;;
  esac
  GOGO_NODE_FILE="node-$GOGO_NODE_VERSION-$GOGO_NODE_ARCH.tar.gz"
  echo "Este computador não tem o Node, ou tem um antigo."
  echo "Baixando o Node $GOGO_NODE_VERSION só para esta pasta, cerca de 45 MB..."
  mkdir -p "$GOGO_RUNTIME" || return 1
  if ! curl -L --fail --silent --show-error -o "$GOGO_RUNTIME/$GOGO_NODE_FILE" "https://nodejs.org/dist/$GOGO_NODE_VERSION/$GOGO_NODE_FILE"; then
    echo "Não deu para baixar o Node. Confira a internet e abra o instalador de novo."
    return 1
  fi
  if [ -n "$GOGO_NODE_SUM" ]; then
    if command -v shasum >/dev/null 2>&1; then
      GOGO_GOT=$(shasum -a 256 "$GOGO_RUNTIME/$GOGO_NODE_FILE" | cut -d' ' -f1)
    else
      GOGO_GOT=$(sha256sum "$GOGO_RUNTIME/$GOGO_NODE_FILE" | cut -d' ' -f1)
    fi
    if [ "$GOGO_GOT" != "$GOGO_NODE_SUM" ]; then
      echo "O arquivo do Node que chegou não confere com o original. Foi apagado; tente de novo."
      rm -f "$GOGO_RUNTIME/$GOGO_NODE_FILE"
      return 1
    fi
  fi
  if ! tar -xzf "$GOGO_RUNTIME/$GOGO_NODE_FILE" -C "$GOGO_RUNTIME" --strip-components=1; then
    echo "Não deu para abrir o arquivo do Node que foi baixado."
    return 1
  fi
  rm -f "$GOGO_RUNTIME/$GOGO_NODE_FILE"
  NODE_EXE="$GOGO_RUNTIME/bin/node"
  if ! gogo_node_ok "$NODE_EXE"; then
    echo "O Node baixado não executou neste computador."
    return 1
  fi
  echo "Node pronto."
fi

PATH="$(dirname "$NODE_EXE"):$PATH"
export PATH
