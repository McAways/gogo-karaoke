@echo off
rem Acha um Node que sirva (22.18 ou mais novo). Se a maquina nao tiver, baixa um so para esta
rem pasta. Devolve NODE_EXE e poe a pasta dele na frente do PATH (o npm fica ao lado).
rem Uso: call suporte\node.cmd [baixar]
set "NODE_EXE="
set "GOGO_RUNTIME=%~dp0..\runtime"
if exist "%GOGO_RUNTIME%\node.exe" set "NODE_EXE=%GOGO_RUNTIME%\node.exe"
if defined NODE_EXE goto :pronto

where node >nul 2>nul
if errorlevel 1 goto :sem_node
node -e "const [a,b]=process.versions.node.split('.').map(Number);process.exit(a>22||(a===22&&b>=18)?0:1)" >nul 2>nul
if errorlevel 1 goto :sem_node
for /f "delims=" %%n in ('where node') do if not defined NODE_EXE set "NODE_EXE=%%n"
if defined NODE_EXE goto :pronto

:sem_node
if /i "%~1"=="baixar" goto :baixar
echo Falta instalar. Abra o arquivo "instalar" primeiro.
exit /b 1

:baixar
set "GOGO_ARCH=x64"
if /i "%PROCESSOR_ARCHITECTURE%"=="ARM64" set "GOGO_ARCH=arm64"
if /i "%PROCESSOR_ARCHITEW6432%"=="ARM64" set "GOGO_ARCH=arm64"
set "GOGO_NODE_FILE=node-v22.23.2-win-%GOGO_ARCH%.zip"
set "GOGO_NODE_SUM=1177b4137ba5adaa56354ae40f1080c7450e8ae09cecb47da459d1c52ac99f97"
if "%GOGO_ARCH%"=="arm64" set "GOGO_NODE_SUM=fec025a6da31757e3b6af84c5a1628e9d38442ca99a2161091d78f2fcfa35ef3"
echo Este computador nao tem o Node, ou tem um antigo.
echo Baixando o Node v22.23.2 so para esta pasta, cerca de 35 MB...
if not exist "%GOGO_RUNTIME%" mkdir "%GOGO_RUNTIME%"
curl.exe -L --fail --silent --show-error -o "%GOGO_RUNTIME%\%GOGO_NODE_FILE%" "https://nodejs.org/dist/v22.23.2/%GOGO_NODE_FILE%"
if errorlevel 1 goto :falhou_baixar
set "GOGO_GOT="
for /f "skip=1 delims=" %%h in ('certutil -hashfile "%GOGO_RUNTIME%\%GOGO_NODE_FILE%" SHA256') do if not defined GOGO_GOT set "GOGO_GOT=%%h"
if defined GOGO_GOT set "GOGO_GOT=%GOGO_GOT: =%"
if "%GOGO_NODE_SUM%"=="" goto :abrir
if /i "%GOGO_GOT%"=="%GOGO_NODE_SUM%" goto :abrir
echo O arquivo do Node que chegou nao confere com o original. Foi apagado; tente de novo.
del "%GOGO_RUNTIME%\%GOGO_NODE_FILE%"
exit /b 1

:abrir
tar.exe -xf "%GOGO_RUNTIME%\%GOGO_NODE_FILE%" -C "%GOGO_RUNTIME%" --strip-components=1
if errorlevel 1 goto :falhou_abrir
del "%GOGO_RUNTIME%\%GOGO_NODE_FILE%"
if not exist "%GOGO_RUNTIME%\node.exe" goto :falhou_abrir
set "NODE_EXE=%GOGO_RUNTIME%\node.exe"
echo Node pronto.
goto :pronto

:falhou_baixar
echo Nao deu para baixar o Node. Confira a internet e abra o instalador de novo.
exit /b 1

:falhou_abrir
echo Nao deu para abrir o arquivo do Node que foi baixado.
exit /b 1

:pronto
for %%d in ("%NODE_EXE%") do set "PATH=%%~dpd;%PATH%"
exit /b 0
