@echo off
setlocal
cd /d "%~dp0"
title Gogo - autorizar endereco
call "%~dp0suporte\node.cmd"
if errorlevel 1 goto :fim
set "SITE=%~1"
if "%SITE%"=="" set /p "SITE=Endereco do app publicado (ex.: https://meu-gogo.vercel.app): "
"%NODE_EXE%" helper\server.ts permitir "%SITE%"
:fim
echo.
pause
