@echo off
setlocal
cd /d "%~dp0"
title Gogo - ajudante
call "%~dp0suporte\node.cmd"
if errorlevel 1 goto :erro
if not exist node_modules\ws goto :falta
"%NODE_EXE%" helper\server.ts
if errorlevel 1 pause
exit /b
:falta
echo Falta instalar. Abra o arquivo "instalar" primeiro.
:erro
pause
exit /b 1
